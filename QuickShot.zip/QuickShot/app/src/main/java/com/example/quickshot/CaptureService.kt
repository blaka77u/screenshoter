package com.example.quickshot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max

class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.example.quickshot.STOP"
        private const val CHANNEL_ID = "quickshot"
        private const val NOTIFICATION_ID = 1
    }

    private lateinit var windowManager: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private lateinit var worker: HandlerThread
    private lateinit var workerHandler: Handler

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    // Последний кадр экрана; всегда актуален, пока идёт запись.
    private val lock = Any()
    private var latestImage: Image? = null

    private var width = 0
    private var height = 0
    private var dpi = 0

    private var overlay: View? = null
    private var posX = 0
    private var posY = 0

    @Volatile
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        worker = HandlerThread("quickshot-worker").also { it.start() }
        workerHandler = Handler(worker.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY // уже запущено

        startInForeground()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = manager.getMediaProjection(code, data)
        projection = mp

        // Начиная с Android 14 callback нужно зарегистрировать до createVirtualDisplay.
        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }
        projectionCallback = callback
        mp.registerCallback(callback, main)

        readScreenSize()
        val reader = newReader()
        imageReader = reader
        virtualDisplay = mp.createVirtualDisplay(
            "quickshot", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )

        posX = dp(16)
        posY = height / 3
        showOverlay()
        return START_NOT_STICKY
    }

    // ---------- Уведомление (обязательно для записи экрана) ----------

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_close),
            getString(R.string.stop),
            stopIntent
        ).build()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_camera)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setOngoing(true)
            .addAction(stopAction)
            .build()
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---------- Захват экрана ----------

    private fun readScreenSize() {
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getRealMetrics(metrics)
        width = metrics.widthPixels
        height = metrics.heightPixels
        dpi = metrics.densityDpi
    }

    private fun newReader(): ImageReader {
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r ->
            val image = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            } ?: return@setOnImageAvailableListener
            synchronized(lock) {
                latestImage?.close()
                latestImage = image
            }
        }, workerHandler)
        return reader
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val display = virtualDisplay ?: return
        val oldReader = imageReader
        readScreenSize()
        val reader = newReader()
        display.resize(width, height, dpi)
        display.surface = reader.surface
        synchronized(lock) {
            latestImage?.close()
            latestImage = null
        }
        imageReader = reader
        oldReader?.close()

        posX = posX.coerceIn(0, max(0, width - dp(120)))
        posY = posY.coerceIn(0, max(0, height - dp(80)))
        if (overlay != null) {
            removeOverlay()
            showOverlay()
        }
    }

    private fun takeScreenshot() {
        if (busy) return
        busy = true
        // Убираем кнопку с экрана, чтобы она не попала на снимок.
        removeOverlay()
        main.postDelayed({
            workerHandler.post {
                val bitmap = grabBitmap()
                main.post { showOverlay() }
                if (bitmap == null) {
                    toast(getString(R.string.shot_failed))
                } else {
                    val ok = save(bitmap)
                    bitmap.recycle()
                    toast(getString(if (ok) R.string.shot_saved else R.string.shot_failed))
                }
                busy = false
            }
        }, 200)
    }

    private fun grabBitmap(): Bitmap? = synchronized(lock) {
        val image = latestImage ?: return null
        try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width
            val full = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
            )
            val buffer = plane.buffer
            buffer.rewind()
            full.copyPixelsFromBuffer(buffer)
            if (full.width == image.width) {
                full
            } else {
                val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
                full.recycle()
                cropped
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun save(bitmap: Bitmap): Boolean {
        return try {
            val name = "Screenshot_" +
                SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".png"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Screenshots")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun toast(text: String) {
        main.post { Toast.makeText(this, text, Toast.LENGTH_SHORT).show() }
    }

    // ---------- Плавающая кнопка ----------

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun circleButton(iconRes: Int, color: Int, size: Int, description: String): ImageView {
        return ImageView(this).apply {
            setImageResource(iconRes)
            setPadding(size / 4, size / 4, size / 4, size / 4)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
            }
            contentDescription = description
        }
    }

    private fun showOverlay() {
        if (overlay != null) return

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(32).toFloat()
                setColor(0xCC202124.toInt())
            }
        }
        val shot = circleButton(R.drawable.ic_camera, 0xFF1A73E8.toInt(), dp(56), getString(R.string.take_shot))
        val close = circleButton(R.drawable.ic_close, 0xFFD93025.toInt(), dp(36), getString(R.string.stop))
        row.addView(shot, LinearLayout.LayoutParams(dp(56), dp(56)))
        row.addView(close, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(8) })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = posX
            y = posY
        }

        shot.setOnClickListener { takeScreenshot() }
        close.setOnClickListener { stopSelf() }

        // Кнопку-камеру можно перетаскивать; короткое касание — это скриншот.
        shot.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - touchX
                        val dy = event.rawY - touchY
                        if (!moved && hypot(dx, dy) > dp(8)) moved = true
                        if (moved) {
                            params.x = startX + dx.toInt()
                            params.y = startY + dy.toInt()
                            posX = params.x
                            posY = params.y
                            windowManager.updateViewLayout(row, params)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) v.performClick()
                }
                return true
            }
        })

        windowManager.addView(row, params)
        overlay = row
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // уже удалено
            }
        }
        overlay = null
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        removeOverlay()
        synchronized(lock) {
            latestImage?.close()
            latestImage = null
        }
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        projection = null
        worker.quitSafely()
        super.onDestroy()
    }
}
